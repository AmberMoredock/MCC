import pandas as pd

df = pd.read_csv('demo_class - Sheet1.csv')

df
